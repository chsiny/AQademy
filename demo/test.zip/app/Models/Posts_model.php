<?php

namespace App\Models;

use CodeIgniter\Model;

class Posts_model extends Model
{
    protected $table = 'Posts';
    protected $allowedFields = ['title', 'username', 'datetime', 'content', 'upvotes', 'isComment'];
    

    public function getPosts()
    {
        return $this->findAll();
    }

    public function getPost($id)
    {
        $builder = $this->db->table('Posts');
        $builder->select('*');
        $builder->where('postId', $id);
        $query = $builder->get();
        return $query->getRow();
    }

    public function upvotePost($id)
    {
        $builder = $this->db->table('Posts');
        $builder->where('postId', $id);
        $builder->set('upvotes', 'upvotes + 1', FALSE);
        $builder->update();
        return;
    }

    public function getComments($postId)
    {
        $builder = $this->db->table('PostsPath');
        $builder->select('Posts.*');
        $builder->join('Posts', 'PostsPath.postId = Posts.postId');
        $builder->where('PostsPath.parentId', $postId);
        $query = $builder->get();
        return $query->getResultArray();
    }

    public function createComment($username, $content, $parentId, $datetime)
    {
        $data = [
            'title' => '',
            'username' => $username,
            'datetime' => $datetime,
            'content' => $content,
            'upvotes' => 0,
            'isComment' => 1
        ];
        $this->insert($data);
    
        // Get the ID of the new comment post
        $newPostId = $this->db->insertID();
    
        // Create PostsPath entry
        $data = [
            'postId' => $newPostId,
            'parentId' => $parentId
        ];
        $this->db->table('PostsPath')->insert($data);

    }

    public function searchPosts($search_term) 
    {
        $search_term = $this->db->escapeLikeString($search_term);
        $builder = $this->db->table('Posts');
        // $builder->select('postId, title');
        $builder->select('*');
        $builder->like('title', $search_term);
        // $builder->orLike('content', $search_term);
        $query = $builder->get();
        return $query->getResultArray();
    }
}