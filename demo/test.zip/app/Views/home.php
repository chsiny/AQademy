<div class="container">
  <div class="row">
    <div class="col-md-12">
      <h1>Posts</h1>
      <a href="<?php echo base_url('/addPost'); ?>" class="btn btn-primary">Add New Post</a>
    </div>
  </div>
    <div class="row">
        <?php foreach ($posts as $post) : ?>
            <?php if ($post['isComment'] == 0) : ?>
                <div class="col-md-4">
                    <div class="card mb-4 box-shadow">
                        <div class="card-body">
                            <h5 class="card-title"><?= $post['title'] ?></h5>
                            <p class="card-text"><?= $post['content'] ?></p>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="btn-group">
                                    <a href="<?php echo base_url('post/' . $post['postId']); ?>" class="btn btn-sm btn-outline-secondary">View</a>
                                    <a href="#" class="btn btn-sm btn-outline-secondary">Edit</a>
                                </div>
                                <small class="text-muted"><?= $post['upvotes'] ?></small>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>
</div>


