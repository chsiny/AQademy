<?php
namespace App\Controllers;
class Upload extends BaseController
{
	public function index() {
        $data['errors'] = "";
        echo view('template/header');
        echo view('upload_form', $data);
        echo view('template/footer');
    }

    public function upload_file() {
        $data['errors'] = "";
        $title = $this->request->getPost('title');
        $file = $this->request->getFile('userfile');
        $file->move(WRITEPATH . 'uploads');
        $filename = $file->getName();
        $model = model('App\Models\Upload_model');
        $check = $model->upload($title, $filename);
        if ($check) {
            echo view('template/header');
            echo "upload_success!";
            echo view('template/footer');
        } else {
            $data['errors'] = "<div class=\"alert alert-danger\" role=\"alert\"> Upload failed!! </div> ";
            echo view('template/header');
            echo view('upload_form', $data);
            echo view('template/footer');
        }
        
    }

    public function profile_picture() {
        $data['errors'] = "";
        $profile_picture = $this->request->getFile('profile_picture');

        $session = session();
        $title = $session->get('username');
        $filename = $title . '_' . time() . '.jpg';
        $profile_picture->move(WRITEPATH . 'uploads', $filename);

        $model = model('App\Models\Upload_model');
        $check = $model->upload($title, $filename);
        
        if ($check) {
            $model = model('App\Models\User_model');
            $model->update_profile_picture($title, $filename);
            return redirect()->to(base_url('/user'));
        } else {
            $data['errors'] = "<div class=\"alert alert-danger\" role=\"alert\"> Upload failed!! </div> ";
            echo view('template/header');
            echo view('upload_form', $data);
            echo view('template/footer');
        }

        // if ($profile_picture->isValid()) {
        //     // Check the file type and size
        //     if ($profile_picture->getClientMimeType() == 'image/jpeg' && $profile_picture->getSize() <= 2048) {
        //         // Generate a unique filename for the uploaded file
        //         $filename = $username . '.jpeg';

        //         // Move the file to a permanent location
        //         $profile_picture->move(WRITEPATH . 'uploads', $filename);

        //         // Save the path of the uploaded file to the user's profile in the database
        //         $model = model('App\Models\Upload_model');
        //         $check = $model->upload($title, $filename);

        //         // Redirect back to the user's profile page
        //         return redirect()->to(base_url('/user'));
        //     } else {
        //         // File type or size is invalid
        //         $data['error'] = 'Invalid file type or size (max 2MB)';
        //     }
        // } else {
        //     // File upload failed
        //     $data['error'] = 'File upload failed';
        // }
        // $model = new \App\Models\User_model();
        // $data['profile_picture'] = $model->getUserPicture($username);
        
    }
}
